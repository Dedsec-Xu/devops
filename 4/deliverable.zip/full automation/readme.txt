This script simply downloads the scripts from my github repo and run vagrant up. 

The installing and running of logstash is in the provision script of the webserver.

The only thing that need to be done by hand is running the ansible playbook.

The output csv will be in the same folder as the vagrant file thank to the sync folder.